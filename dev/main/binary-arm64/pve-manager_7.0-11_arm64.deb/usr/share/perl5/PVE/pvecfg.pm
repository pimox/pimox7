package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '7.0-11';
}

sub release {
    return '7.0';
}

sub repoid {
    return '198875f9';
}

sub version_text {
    return '7.0-11/198875f9';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '7.0-11',
	'release' => '7.0',
	'repoid' => '198875f9',
    }
}

1;
