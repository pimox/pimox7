package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '7.0-11';
}

sub release {
    return '7.0';
}

sub repoid {
    return '134abb41';
}

sub version_text {
    return '7.0-11/134abb41';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '7.0-11',
	'release' => '7.0',
	'repoid' => '134abb41',
    }
}

1;
