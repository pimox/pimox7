package PVE::RS::APT::Repositories;
use base 'Proxmox::Lib::PVE';
BEGIN { __PACKAGE__->bootstrap(); }
1;
