package PVE::RS::TFA;
use base 'Proxmox::Lib::PVE';
BEGIN { __PACKAGE__->bootstrap(); }
1;
