package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '7.0-13';
}

sub release {
    return '7.0';
}

sub repoid {
    return 'd36ac0ea';
}

sub version_text {
    return '7.0-13/d36ac0ea';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '7.0-13',
	'release' => '7.0',
	'repoid' => 'd36ac0ea',
    }
}

1;
