mod compression;
pub use compression::*;

pub mod tar;
pub mod zip;
pub mod zstd;
