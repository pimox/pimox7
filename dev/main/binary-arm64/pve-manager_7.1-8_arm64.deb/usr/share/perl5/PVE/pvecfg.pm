package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '7.1-8';
}

sub release {
    return '7.1';
}

sub repoid {
    return '7cd00e36';
}

sub version_text {
    return '7.1-8/7cd00e36';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '7.1-8',
	'release' => '7.1',
	'repoid' => '7cd00e36',
    }
}

1;
