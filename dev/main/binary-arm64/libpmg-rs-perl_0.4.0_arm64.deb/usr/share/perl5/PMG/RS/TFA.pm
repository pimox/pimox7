package PMG::RS::TFA;

require DynaLoader;

sub bootstrap {
    my ($pkg) = @_;
    my ($mod_name) = ('pmg_rs');
    my $bootstrap_name = 'xs_bootstrap_' . ($pkg =~ s/::/__/gr);

    my @dirs = (map "-L$_/auto", @INC);
    my $mod_file = DynaLoader::dl_findfile(@dirs, $mod_name);
    die "failed to locate shared library for '$pkg' (lib${mod_name}.so)\n" if !$mod_file;

    my $lib = DynaLoader::dl_load_file($mod_file)
        or die "failed to load library '$mod_file'\n";

    my $sym  = DynaLoader::dl_find_symbol($lib, $bootstrap_name);
    die "failed to locate '$bootstrap_name'\n" if !defined $sym;
    my $boot = DynaLoader::dl_install_xsub($bootstrap_name, $sym, "src/FIXME.rs");
    $boot->();
}

__PACKAGE__->bootstrap;

1;
