package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '7.1-10';
}

sub release {
    return '7.1';
}

sub repoid {
    return '821f136a';
}

sub version_text {
    return '7.1-10/821f136a';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '7.1-10',
	'release' => '7.1',
	'repoid' => '821f136a',
    }
}

1;
