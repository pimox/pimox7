package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '7.1-7';
}

sub release {
    return '7.1';
}

sub repoid {
    return '09b7cf08';
}

sub version_text {
    return '7.1-7/09b7cf08';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '7.1-7',
	'release' => '7.1',
	'repoid' => '09b7cf08',
    }
}

1;
