package PVE::RS::OpenId;

use strict;
use warnings;
use DynaLoader ();

my $LIB;

BEGIN {
    my sub newXS {
        my ($perl_func_name, $full_symbol_name, $filename) = @_;

        my $sym  = DynaLoader::dl_find_symbol($LIB, $full_symbol_name);
        die "failed to locate '$full_symbol_name'\n" if !defined $sym;
        DynaLoader::dl_install_xsub($perl_func_name, $sym, $filename);
    }

    my sub __load_shared_lib {
        return if $LIB;

        my ($pkg) = @_;

        my ($mod_name) = ('pve_rs');

        my @dirs = (map "-L$_/auto", @INC);
        my (@mod_files) = DynaLoader::dl_findfile(@dirs, $mod_name);
        die "failed to locate shared library for '$pkg' (lib${mod_name}.so)\n" if !@mod_files;

        $LIB = DynaLoader::dl_load_file($mod_files[0])
            or die "failed to load library '$mod_files[0]'\n";
    }

    __load_shared_lib(__PACKAGE__);
    newXS('DESTROY', 'xs_PVE__RS__OpenId_destroy', "src/FIXME.rs");
    newXS('discover', 'xs_PVE__RS__OpenId_discover', "src/FIXME.rs");
    newXS('authorize_url', 'xs_PVE__RS__OpenId_authorize_url', "src/FIXME.rs");
    newXS('verify_public_auth_state', 'xs_PVE__RS__OpenId_verify_public_auth_state', "src/FIXME.rs");
    newXS('verify_authorization_code', 'xs_PVE__RS__OpenId_verify_authorization_code', "src/FIXME.rs");
}
