package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '7.2-7';
}

sub release {
    return '7.2';
}

sub repoid {
    return 'f1b67e2b';
}

sub version_text {
    return '7.2-7/f1b67e2b';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '7.2-7',
	'release' => '7.2',
	'repoid' => 'f1b67e2b',
    }
}

1;
