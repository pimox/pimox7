export class PoolEditModeResponseModel {
  mirror_mode: string;
}
