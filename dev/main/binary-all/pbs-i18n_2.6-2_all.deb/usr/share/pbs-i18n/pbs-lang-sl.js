// -
// Proxmox Message Catalog: pbs-lang-sl.js
__proxmox_i18n_msgcat__ = {"1010534570":["Dosegljiv"],"102017518":["Omogoči"],"1095677363":["Povzetek"],"1097310050":["Vsebina"],"1117080514":["Nazaj"],"1120365745":["Uredi"],"1121548025":["Čas delovanja"],"112472755":["Uporabniki"],"113230335":["Varnostne kopije"],"1155649139":["Izbriši {0} vnos?"],"117505411":["Pravice"],"1179034313":["Iskanje"],"125463051":["Odjava"],"1266644741":["Ustavi"],"1277169241":["Neznano"],"1288449246":["Naloži naročniški ključ"],"129717419":["Vpiši pravilno DNS ime"],"1308245100":["Čas zagona"],"1312749210":["CPU poraba"],"1313942339":["Neznana napaka"],"135637716":["Osveži"],"1364578413":["Vrsta"],"1397651250":["Način"],"1432485131":["Splošno"],"1441655762":["Prijava"],"1496092135":["Preveri ključ"],"1509197333":["Omrežna kartica"],"1517138453":["Uporabniško ime"],"1524227104":["Potrdi geslo"],"1558370824":["Naprej"],"1573770551":["Različica"],"1582017048":["Pogled"],"1591441098":["Konzola"],"1608836100":["Čas"],"1621507602":["Uporabnik"],"1642511898":["Ne"],"1672675413":["Servisi"],"1682907645":["dan"],"1692103706":["Pasovni čas"],"1725856265":["Opis"],"1756866391":["DNS strežnik"],"1768209177":["Prenesi"],"1789283792":["Uporabljeno"],"1801905238":["Pot"],"180669460":["IP naslov"],"180921696":["Resetiraj"],"180965513":["nikoli"],"1827006442":["Napaka pri prijavi! Poizkusi ponovno"],"182978943":["Zaženi"],"1837256131":["Poraba diska"],"1839360066":["Poteče"],"1843267341":["Dovoljeni znaki"],"1853244196":["Rezultat"],"1860367182":["ustavljeno"],"1911669355":["Zaustavi"],"1938660593":["Napaka"],"1971275149":["Skupine"],"1974461284":["Vsi"],"1989268106":["dni"],"2003021401":["Uporabniška dovoljenja"],"2018011009":["Overjanje"],"2023431579":["Uspešno"],"2123320219":["Paket"],"266367750":["Ime"],"267393898":["Zapiski"],"267943793":["Obnovi"],"271285817":["Vloga"],"311628609":["Primer"],"330376117":["Poraba pomnilnika"],"337799720":["Mapa"],"340849291":["Naročniški ključ"],"343848780":["se izvaja"],"370850709":["Kompresija"],"397479987":["Nalagam..."],"407871486":["Komentar"],"40861564":["Naloži"],"420340861":["Ustvari"],"420819256":["Ime"],"433860734":["Privzeto"],"434265056":["Priimek"],"440640172":["Odpri ponovno"],"443800475":["Jezik"],"455261812":["Lastnik"],"478602302":["Omogočeno"],"499362324":["Dodaj"],"529077071":["Aktiven"],"557963277":["Pravice"],"562285039":["Potrdi"],"564498461":["Odstrani"],"583450315":["Ni sprememb"],"6222351":["Stanje"],"642223740":["Velikost"],"711771863":["Končano ob"],"750979128":["Geslo"],"761816144":["Omrežna maska"],"765964251":["brez"],"772725124":["Sporočilo"],"793046412":["Ponovno zaženi"],"806397589":["Čakam na uveljavitev sprememb"],"866399792":["Da"],"879231789":["Strežnik"],"893259077":["Možnosti"],"91525164":["Skupina"],"947972530":["Razpored tipkovnice"],"966695021":["Opravila"],"974794979":["Napaka pri povezavi"],"989937162":["Počakaj..."]};

function fnv31a(text) {
    var len = text.length;
    var hval = 0x811c9dc5;
    for (var i = 0; i < len; i++) {
	var c = text.charCodeAt(i);
	hval ^= c;
	hval += (hval << 1) + (hval << 4) + (hval << 7) + (hval << 8) + (hval << 24);
    }
    hval &= 0x7fffffff;
    return hval;
}

function gettext(buf) {
    var digest = fnv31a(buf);
    var data = __proxmox_i18n_msgcat__[digest];
    if (!data) {
	return buf;
    }
    return data[0] || buf;
}
