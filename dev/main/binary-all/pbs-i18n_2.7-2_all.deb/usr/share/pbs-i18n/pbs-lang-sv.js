// -
// Proxmox Message Catalog: pbs-lang-sv.js
__proxmox_i18n_msgcat__ = {"1010534570":["Online"],"102017518":["Aktivera"],"1095677363":["Sammanfattning"],"1097310050":["Innehåll"],"1117080514":["Tillbaka"],"1120365745":["Redigera"],"1121548025":["Upptid"],"112472755":["Användare"],"113230335":["Säkerhetskopiering"],"1155649139":["Är du säker på att du vill ta bort posten {0}"],"117505411":["Rättigheter"],"1179034313":["Sök"],"125463051":["Logga ut"],"1266644741":["Stoppa"],"1277169241":["Okänd"],"1308245100":["Starttid"],"1312749210":["CPU-användning"],"1313942339":["Okänt fel"],"135637716":["Uppdatera"],"1364578413":["Typ"],"1397651250":["Läge"],"1432485131":["Allmänt"],"1441655762":["Logga in"],"1509197333":["Nätverksenhet"],"1517138453":["Användarnamn"],"1524227104":["Bekräfta lösenord"],"1558370824":["Nästa"],"1573770551":["Version"],"1582017048":["Vy"],"1591441098":["Konsol"],"1608836100":["Tid"],"1621507602":["Användare"],"1642511898":["Ingen"],"1672675413":["Tjänster"],"1682907645":["dag"],"1692103706":["Tidszon"],"1725856265":["Beskrivning"],"1756866391":["DNS-server"],"1768209177":["Ladda ner"],"1789283792":["Använt"],"1801905238":["Sökväg"],"180669460":["IP-adress"],"180921696":["Återställ"],"180965513":["aldrig"],"1827006442":["Inloggning misslyckades. Försök igen"],"182978943":["Starta"],"1837256131":["Diskanvändning"],"1839360066":["Gå ut"],"1843267341":["Tillåtna tecken"],"1853244196":["Utdata"],"1860367182":["stoppad"],"1911669355":["Stäng av"],"1938660593":["Fel"],"1971275149":["Grupper"],"1974461284":["Alla"],"1989268106":["dagar"],"2003021401":["Användarrättigheter"],"2023431579":["Lyckad"],"2025656483":["Pool"],"2123320219":["Paket"],"2142306162":["Format"],"266367750":["Namn"],"267393898":["Anteckningar"],"267943793":["Återställ"],"271285817":["Roll"],"311628609":["Exempel"],"330376117":["Minnesanvändning"],"337799720":["Mapp"],"343848780":["igång"],"370850709":["Komprimering"],"397479987":["Laddar..."],"400411952":["Domän"],"407871486":["Kommentar"],"40861564":["Ladda upp"],"420340861":["Skapa"],"420819256":["Förnamn"],"433860734":["Standard"],"434265056":["Efternamn"],"440640172":["Uppdatera"],"443800475":["Språk"],"455261812":["Ägare"],"478602302":["Aktiverad"],"499362324":["Lägg till"],"529077071":["Aktiv"],"557963277":["Privilegier"],"562285039":["Bekräfta"],"564498461":["Ta bort"],"583450315":["Inga ändringar"],"599530703":["Servertid"],"6222351":["Status"],"642223740":["Storlek"],"711771863":["Sluttid"],"750979128":["Lösenord"],"761816144":["Nätmask"],"765964251":["ingen"],"772725124":["Meddelande"],"793046412":["Starta om"],"806397589":["Pågående ändringar"],"866399792":["Ja"],"879231789":["Nod"],"888343212":["Propagera"],"893259077":["Alternativ"],"91525164":["Grupp"],"947972530":["Tangentbordslayout"],"966695021":["Uppgifter"],"974743969":["Shell"],"974794979":["Anslutningsfel"],"989937162":["Vänta..."]};

function fnv31a(text) {
    var len = text.length;
    var hval = 0x811c9dc5;
    for (var i = 0; i < len; i++) {
	var c = text.charCodeAt(i);
	hval ^= c;
	hval += (hval << 1) + (hval << 4) + (hval << 7) + (hval << 8) + (hval << 24);
    }
    hval &= 0x7fffffff;
    return hval;
}

function gettext(buf) {
    var digest = fnv31a(buf);
    var data = __proxmox_i18n_msgcat__[digest];
    if (!data) {
	return buf;
    }
    return data[0] || buf;
}
