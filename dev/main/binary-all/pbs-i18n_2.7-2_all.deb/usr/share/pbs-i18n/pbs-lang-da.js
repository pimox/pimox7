// -
// Proxmox Message Catalog: pbs-lang-da.js
__proxmox_i18n_msgcat__ = {"1010534570":["Online"],"102017518":["Aktivér"],"1095677363":["Oversigt"],"1097310050":["Indhold"],"1117080514":["Tilbage"],"1120365745":["Redigér"],"1121548025":["Oppetid"],"112472755":["Brugere"],"113230335":["Backup"],"1155649139":["Er du sikker på at du vil fjerne punktet {0}"],"117505411":["Tilladelser"],"1179034313":["Søg"],"125463051":["Log ud"],"1266644741":["Stop"],"1277169241":["Ukendt"],"1288449246":["Upload Subscriptionnøgle"],"129717419":["Dette er ikke et gyldigt DNS-navn"],"1308245100":["Starttidspunkt"],"1312749210":["CPU-forbrug"],"1313942339":["Ukendt fejl"],"135637716":["Opdatér"],"1364578413":["Type"],"1397651250":["Metode"],"1432485131":["Generelt"],"1441655762":["Login"],"1496092135":["Tjek"],"1509197333":["Netværksenhed"],"1517138453":["Brugernavn"],"1524227104":["Bekræft adgangskode"],"1558370824":["Næste"],"1573770551":["Version"],"1582017048":["Oversigt"],"1591441098":["Konsol"],"1608836100":["Tid"],"1621507602":["Bruger"],"1642511898":["Nej"],"1672675413":["Tjenester"],"1682907645":["dag"],"1692103706":["Tidszone"],"1725856265":["Beskrivelse"],"1756866391":["DNS-server"],"1768209177":["Hent"],"1789283792":["Brugt"],"1801905238":["Sti"],"180669460":["IP-adresse"],"180921696":["Genstart"],"180965513":["aldrig"],"1827006442":["Login fejlet. Prøv venligst igen"],"182978943":["Start"],"1837256131":["Diskforbrug"],"1839360066":["Udløber"],"1843267341":["Tilladte karaktérer"],"1853244196":["Output"],"1860367182":["stoppet"],"1911669355":["Sluk"],"1938660593":["Fejl"],"1971275149":["Grupper"],"1974461284":["Alle"],"1989268106":["dage"],"2003021401":["Brugertilladelse"],"2023431579":["Vellykket"],"2025656483":["Pulje"],"2123320219":["Pakke"],"2142306162":["Format"],"266367750":["Navn"],"267393898":["Notater"],"267943793":["Gendan"],"271285817":["Rolle"],"311628609":["Eksempel"],"330376117":["Hukommelsesforbrug"],"337799720":["Katalog"],"340849291":["Subscriptionnøgle"],"343848780":["kører"],"370850709":["Komprimering"],"397479987":["Indlæser..."],"400411952":["Realm"],"407871486":["Kommentar"],"40861564":["Upload"],"420340861":["Opret"],"420819256":["Fornavn"],"433860734":["Standard"],"434265056":["Efternavn"],"440640172":["Genindlæs"],"443800475":["Sprog"],"455261812":["Ejer"],"478602302":["Aktivéret"],"499362324":["Tilføj"],"529077071":["Aktiv"],"557963277":["Rettigheder"],"562285039":["Bekræft"],"564498461":["Fjern"],"583450315":["Ingen ændringer"],"599530703":["Servertid"],"6222351":["Status"],"642223740":["Størrelse"],"711771863":["Sluttid"],"750979128":["Adgangskode"],"761816144":["Subnet mask"],"765964251":["ingen"],"772725124":["Besked"],"793046412":["Genstart"],"806397589":["Afventende ændringer"],"866399792":["Ja"],"879231789":["Node"],"888343212":["Rekursiv"],"893259077":["Indstillinger"],"91525164":["Gruppe"],"947972530":["Tastaturopsætning"],"966695021":["Opgaver"],"974743969":["Konsol"],"974794979":["Forbindelsesfejl"],"989937162":["Vent venligst..."]};

function fnv31a(text) {
    var len = text.length;
    var hval = 0x811c9dc5;
    for (var i = 0; i < len; i++) {
	var c = text.charCodeAt(i);
	hval ^= c;
	hval += (hval << 1) + (hval << 4) + (hval << 7) + (hval << 8) + (hval << 24);
    }
    hval &= 0x7fffffff;
    return hval;
}

function gettext(buf) {
    var digest = fnv31a(buf);
    var data = __proxmox_i18n_msgcat__[digest];
    if (!data) {
	return buf;
    }
    return data[0] || buf;
}
