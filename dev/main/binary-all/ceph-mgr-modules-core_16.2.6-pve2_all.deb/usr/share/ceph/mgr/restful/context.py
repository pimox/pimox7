# Global instance to share
instance = None
