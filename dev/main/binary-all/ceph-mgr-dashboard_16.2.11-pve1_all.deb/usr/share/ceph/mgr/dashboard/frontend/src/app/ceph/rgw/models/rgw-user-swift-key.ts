export class RgwUserSwiftKey {
  user: string;
  secret_key: string;
}
