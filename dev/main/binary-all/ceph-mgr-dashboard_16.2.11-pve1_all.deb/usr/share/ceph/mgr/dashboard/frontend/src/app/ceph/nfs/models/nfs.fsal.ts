export interface NfsFSAbstractionLayer {
  value: string;
  descr: string;
  disabled: boolean;
}
