var searchData=
[
  ['major_704',['major',['../structqb__version.html#afbebdeeb94a355ff4018226f7bbbb5e3',1,'qb_version']]],
  ['micro_705',['micro',['../structqb__version.html#acb393b1fbaf6b3a09115f5a5bd905ef5',1,'qb_version']]],
  ['minor_706',['minor',['../structqb__version.html#a34e1c22569cf4787f36ef8423f911448',1,'qb_version']]],
  ['msg_5fprocess_707',['msg_process',['../structqb__ipcs__service__handlers.html#ad0b578351ef8347b170347488da7dc71',1,'qb_ipcs_service_handlers']]]
];
