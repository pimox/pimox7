var searchData=
[
  ['qb_5fver_711',['qb_ver',['../qbutil_8h.html#a75c71a10cd781783764be816b8dabbba',1,'qbutil.h']]],
  ['qb_5fver_5fstr_712',['qb_ver_str',['../qbutil_8h.html#a48479fa5498ac50126a9bbbd66400e35',1,'qbutil.h']]]
];
