var searchData=
[
  ['ipc_20overview_921',['IPC Overview',['../qb_ipc_overview.html',1,'index']]]
];
