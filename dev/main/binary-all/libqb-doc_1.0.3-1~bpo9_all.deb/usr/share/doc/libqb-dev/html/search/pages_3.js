var searchData=
[
  ['handle_20database_920',['Handle Database',['../qb_hdb_overview.html',1,'index']]]
];
