var searchData=
[
  ['handle_5fcount_697',['handle_count',['../structqb__hdb.html#af1b10904b26854e8d7fa2500b0783e1f',1,'qb_hdb']]],
  ['handles_698',['handles',['../structqb__hdb.html#abcc15bba6219ca87512088583d0a6d98',1,'qb_hdb']]]
];
