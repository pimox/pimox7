var searchData=
[
  ['handle_20database_28',['Handle Database',['../qb_hdb_overview.html',1,'index']]],
  ['handle_5fcount_29',['handle_count',['../structqb__hdb.html#af1b10904b26854e8d7fa2500b0783e1f',1,'qb_hdb']]],
  ['handles_30',['handles',['../structqb__hdb.html#abcc15bba6219ca87512088583d0a6d98',1,'qb_hdb']]],
  ['hz_31',['HZ',['../qbdefs_8h.html#a8489802eaedf42fdb5f2ce1708eaffa2',1,'qbdefs.h']]]
];
