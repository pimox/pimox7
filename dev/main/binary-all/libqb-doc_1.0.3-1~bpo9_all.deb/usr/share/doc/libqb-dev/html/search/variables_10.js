var searchData=
[
  ['tags_721',['tags',['../structqb__log__callsite.html#a8561f30b7fd7730cb3d39da1cdd963e5',1,'qb_log_callsite::tags()'],['../qblog_8h.html#ac3fc73ca2f0f032be6ea70f9e9cb8837',1,'tags():&#160;qblog.h']]],
  ['targets_722',['targets',['../structqb__log__callsite.html#ab47825dd3acbb32bff816d430d992951',1,'qb_log_callsite::targets()'],['../qblog_8h.html#a210bb1d2223f955a06ea3eb0a25bdb42',1,'targets():&#160;qblog.h']]]
];
