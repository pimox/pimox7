<?php

$magicWords = [];

$magicWords['en'] = [
    'pvedocs' => [ 0, 'pvedocs' ], # case-insensitive, name
];
